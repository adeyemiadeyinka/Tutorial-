Javascript code
// Add event listeners for the forms
document.getElementById('signup-form').addEventListener('submit', function (e) {
    e.preventDefault();
    const username = document.getElementById('signup-username').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    // You can implement signup logic here
    console.log('Sign up:', username, email, password);
});

document.getElementById('signin-form').addEventListener('submit', function (e) {
    e.preventDefault();
    const email = document.getElementById('signin-email').value;
    const password = document.getElementById('signin-password').value;
    // You can implement signin logic here
    console.log('Sign in:', email, password);
});
